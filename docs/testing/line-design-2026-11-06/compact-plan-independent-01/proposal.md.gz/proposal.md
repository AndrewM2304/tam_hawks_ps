# Merchant Yard: compact default-level replan —7November2026

**Replace the sprawling default with one enclosed112×88m Merchant Yard level containing three adjacent courts.** Move the whole existing40×30m sunken skatepark into the basin court at real scale; select and compose existing stairs, bank/rail/ledge and quarter around the street/loading courts. Cut the156m quay,103m promenade, scenic hillside and remote river/railway/pond content from the default scene. Keep them as the optional **City Tour**, loaded separately, with old saves and content intact.

This is a concrete design draft and source-compatibility decision record, not an implementation or admission. The owner’s10:31 request explicitly supersedes the earlier assumption that all six geographic arenas and their distances must remain default. The old six-arena L1 gate is **superseded for the new default, not passed**. Native contact, score deadlines, realism, current feature availability in City Tour, Music isolation and hardware/evidence standards remain.

The first120×96m sketch had too much unexplained surrounding rectangle; it is reduced to112×88m. All remaining exterior space must be a shown solid warehouse/store footprint or playable boundary return, never more empty paving. No uniform coordinate/rider/feature scaling is used. See the machine plan for exact current source pins and architectural masses.

## Layout

| Court | Exact proposed footprint | Behavior |
| --- | --- | --- |
| Merchant Yard | X−48…10/Z−10…34, groundY0 | Stair/rail, bank/manual, short scored gap and useful west/south boundary returns; spawn sees three distinct choices. |
| Loading Hall | X−48…12/Z−44…−12, floorY0, mezzanineY2.2, roofY4.5 | Grounded sheltered line under a playable upper line; loading steps/hall ledge aim toward yard or basin rather than a long street. Roof underside4.2m needs actual full-trick/body/chase clearance. |
| Foundry Basin | X10…50/Z−7…23 | Reuse complete unit-scale40×30m facility, rotate180° at(30,0,8). Real deep/shallow bowls, hip and lower streetY−1.5; rimY0. Existing entry/10m beginner bank faces the yard. |

The yard↔hall opening is10m wide at(0,0,−11); yard↔basin uses the actual4.5m entry at(10,0,3). Hall↔basin needs a **new compact-only6m opening** in the existing rotated south retaining wall, with an8m grade to the lower street. That wall is currently solid; drawing an arrow through it is not compatibility proof. Bowl/port floor voids must remain exact.

Spawn(−4,0.08,14) faces the common junction: west bank/quarter, north stair/rail/roof, east short gap/basin. Camera visibility and native access are targets, not current results.

## Immediate construction rule

Do not instantiate the old world behind the new map. Main should create one selected world through a lazy world factory: **Merchant Yard** by default, **City Tour** explicitly selectable. Reuse existing modules and materials, not the broad-world `_ready` builder or all its façade/landscape objects. No actual source changes occur while full03 is frozen.

Current GlasgowSquare declares21 public methods. Preserve those21 through a world adapter and add `get_level_manifest` / `get_activity_layout` for a23-method proposal; do not misreport23 existing custom methods. FeatureHub contains hardcoded service gate, scenic laps, cone-water and cart coordinates and calls several optional objects unconditionally. A data-driven activity layout plus omitted-object guards is required; an empty route list alone cannot safely remove them.

Profiles need level domains: migrate v1 completion/best records into City Tour, keep settings/cosmetics/unlocks global, and create separate compact career progress. Preserve backups/future-version refusal. Old geographic achievements must not be relabelled as new compact clears; Music/global personal-account behavior is unchanged.

## New default acceptance draft

Two genuinely different returnable lines per **three** courts, three closed cross-court circuits, three visible spawn choices, safe grounded main bypasses, and every scored gap landing aimed at another useful action. Reference next-choice interval1.5–2s at8m/s means12–16m, requiring actual native event/time proof across novice/flow/expert speeds; this is not a count-based pass. Boundary returns must work in both directions with native board/tyre/sole/capsule/chase clearance and deliberate misses. Existing score windows/minimum speeds/contact tolerances remain unchanged.

## Reference scope

Root inspected twelve sampled frames from the [GameSpot Warehouse footage](https://www.gamespot.com/videos/tony-hawks-pro-skater-1-2-high-score-gameplay/2300-6453552/): curved perimeter returns, stacked halfpipe/underpass, central rail/kicker/upper-ledges sharing arrivals, and small purposeful flats with several nearby approaches. The edited clip resets its timer and is **not** a continuous-combo proof. No franchise frame/clip/layout is bundled. Additional root-owned references and the [existing developer/player-guide study](../research/THPS-LINE-DESIGN.md) inform original design, not copying.

Next draft adds the exact feature slots, three loop/event graphs, full interface/goal/route migration, conservative envelope accounting, build tickets and private graybox plan. Native/moving/resource/M5/owner gates remain unmeasured; current source134/0 focused proof and still-running full03 retain their original source scopes.

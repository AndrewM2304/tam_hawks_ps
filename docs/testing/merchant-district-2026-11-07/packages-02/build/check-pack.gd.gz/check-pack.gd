extends SceneTree
func _initialize() -> void:
	var report: Dictionary = {"voice_streams": {}, "textures": {}, "human_meshes": {}, "main_scene_loaded": false}
	var main_scene := load("res://game/main.tscn") as PackedScene
	if main_scene == null:
		push_error("Pack is missing its main scene or script dependencies.")
		quit(1)
		return
	var instance := main_scene.instantiate()
	if instance.get_script() == null:
		push_error("Pack main scene has no loadable game script.")
		instance.free()
		quit(1)
		return
	instance.free()
	report.main_scene_loaded = true
	var durations: Dictionary = {"landing": 0.9495, "cone": 1.2485, "again": 1.137875}
	for id: String in durations:
		var path := "res://game/audio/generated/%s.wav" % id
		var stream := load(path) as AudioStreamWAV
		if stream == null or absf(stream.get_length() - float(durations[id])) > 0.03:
			push_error("Pack is missing the expected imported voice stream: " + path)
			quit(1)
			return
		report.voice_streams[id] = {"resource": path, "seconds": stream.get_length()}
	for material: String in ["T_bricks01", "T_concrete01"]:
		for channel: String in ["albedo", "normal_opengl"]:
			var path := "res://game/art/assets/zc_textures/%s/%s_%s.jpg" % [material, material, channel]
			var texture := load(path) as Texture2D
			if texture == null or texture.get_width() <= 0 or texture.get_height() <= 0 or texture.get_width() > 1024 or texture.get_height() > 1024:
				push_error("Pack is missing a bounded imported material texture: " + path)
				quit(1)
				return
			var image := texture.get_image()
			if image == null or not image.has_mipmaps():
				push_error("Pack texture is missing its image or required mipmaps: " + path)
				quit(1)
				return
			report.textures[path] = {"width": texture.get_width(), "height": texture.get_height(), "mipmaps": image.get_mipmap_count()}
	for id: String in ["head", "hair", "left_hand", "right_hand"]:
		var path := "res://game/art/assets/makehuman_hm08/%s.obj" % id
		var mesh := load(path) as ArrayMesh
		if mesh == null or mesh.get_surface_count() == 0 or mesh.surface_get_array_len(0) < 50:
			push_error("Pack is missing cropped anatomical mesh: " + path)
			quit(1)
			return
		report.human_meshes[id] = {"resource": path, "surfaces": mesh.get_surface_count(), "vertices": mesh.surface_get_array_len(0)}
	var environment_manifest: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://game/art/assets/environment_pbr/manifest.json"))
	var rider_manifest: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://game/art/rider/manifest.json"))
	if not environment_manifest is Dictionary or not rider_manifest is Dictionary:
		push_error("Pack is missing its readable fidelity provenance manifests.")
		quit(1)
		return
	for material: Dictionary in environment_manifest.materials.values():
		for channel: String in material.files:
			var policy: Dictionary = environment_manifest.import_policy.maximum_dimension_by_map
			var cap := int(policy.get(channel, 1024)) if material.provider == "Poly Haven" else int(policy.zc_materials_all_maps)
			if not _fidelity_texture(str(material.files[channel]), cap, report):
				quit(1)
				return
	var merchant_manifest: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://game/art/assets/merchant_pbr/manifest.json"))
	if not merchant_manifest is Dictionary or merchant_manifest.get("licence", "") != "CC0-1.0":
		push_error("Pack is missing Merchant material provenance.")
		quit(1)
		return
	for material: Dictionary in merchant_manifest.materials.values():
		for channel: String in material.files:
			var cap: int = 2048 if channel == "albedo" else 1024
			var path: String = str(material.files[channel])
			if not _fidelity_texture(path, cap, report):
				quit(1)
				return
			var texture: Texture2D = load(path) as Texture2D
			var image: Image = texture.get_image()
			var expected_format: int = Image.FORMAT_RGTC_RG if channel == "normal_opengl" else Image.FORMAT_DXT1
			if image.get_format() != expected_format or texture.get_width() != cap or texture.get_height() != cap:
				push_error("Packed Merchant map changed its Mac-compatible format/size: " + path)
				quit(1)
				return
			report.textures[path]["format"] = image.get_format()
	for data_path: String in ["res://game/levels/merchant_layout.json", "res://game/levels/art/merchant_surface_zones.json"]:
		if not JSON.parse_string(FileAccess.get_file_as_string(data_path)) is Dictionary:
			push_error("Pack is missing selected-world runtime data: " + data_path)
			quit(1)
			return
	for name: String in rider_manifest.maps:
		if not _fidelity_texture("res://game/art/rider/" + name, 2048, report):
			quit(1)
			return
	var derived_manifest: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://game/art/assets/environment_pbr/derived/manifest.json"))
	if not derived_manifest is Dictionary:
		push_error("Pack is missing its derived-surface provenance.")
		quit(1)
		return
	for name: String in derived_manifest.files:
		var cap := 2048 if name.begins_with("pavement_") else 1024
		if not _fidelity_texture("res://game/art/assets/environment_pbr/derived/" + name, cap, report):
			quit(1)
			return
	var fitted_path := "res://game/art/rider/fitted-manifest.json"
	var has_fitted := FileAccess.file_exists(fitted_path)
	var hair_path := "res://game/art/rider/fitted_hair.obj" if has_fitted else "res://game/art/rider/short_crop.obj"
	var hair := load(hair_path) as ArrayMesh
	if hair == null or hair.get_surface_count() != 1 or hair.surface_get_array_len(0) < 1000:
		push_error("Pack is missing its single-surface cropped hair mesh.")
		quit(1)
		return
	if has_fitted and not _fitted_resources(fitted_path, report):
		quit(1)
		return
	if not _board_resource(report):
		quit(1)
		return
	var output := FileAccess.open(OS.get_cmdline_user_args()[0], FileAccess.WRITE)
	if output == null:
		push_error("Could not write packaged resource report.")
		quit(1)
		return
	output.store_string(JSON.stringify(report, "\t") + "\n")
	output.close()
	print("RESOURCES VERIFIED: main scene/scripts, 3 voice streams, ", report.textures.size(), " material/rider textures and 4 anatomical meshes")
	quit(0)

func _fidelity_texture(path: String, cap: int, report: Dictionary) -> bool:
	var texture := load(path) as Texture2D
	if texture == null or texture.get_width() <= 0 or texture.get_height() <= 0 or texture.get_width() > cap or texture.get_height() > cap:
		push_error("Pack is missing its bounded fidelity texture: " + path)
		return false
	var image := texture.get_image()
	if image == null or not image.has_mipmaps():
		push_error("Packed fidelity texture has no image/mipmaps: " + path)
		return false
	report.textures[path] = {"width": texture.get_width(), "height": texture.get_height(), "mipmaps": image.get_mipmap_count()}
	return true

func _fitted_resources(manifest_path: String, report: Dictionary) -> bool:
	var manifest: Variant = JSON.parse_string(FileAccess.get_file_as_string(manifest_path))
	if not manifest is Dictionary or int(manifest.get("schema", -1)) != 1:
		push_error("Pack is missing readable fitted-rider provenance.")
		return false
	report.fitted_resources = {}
	for name: String in manifest.outputs:
		var path := "res://game/art/rider/" + name
		if name.ends_with(".json"):
			var parser := JSON.new()
			if not FileAccess.file_exists(path) or parser.parse(FileAccess.get_file_as_string(path)) != OK:
				push_error("Pack is missing readable fitted-rider metadata: " + path)
				return false
			report.fitted_resources[name] = {"kind": "json"}
		elif name.ends_with(".obj"):
			var mesh := load(path) as ArrayMesh
			if mesh == null or mesh.get_surface_count() == 0 or mesh.surface_get_array_len(0) < 3:
				push_error("Pack is missing an imported fitted-rider mesh: " + path)
				return false
			report.fitted_resources[name] = {"kind": "mesh", "surfaces": mesh.get_surface_count(), "vertices": mesh.surface_get_array_len(0)}
		elif name.ends_with(".glb"):
			var scene := load(path) as PackedScene
			if scene == null:
				push_error("Pack is missing an imported fitted-rider scene: " + path)
				return false
			var actor := scene.instantiate()
			var meshes := actor.find_children("*", "MeshInstance3D", true, false)
			var skeletons := actor.find_children("*", "Skeleton3D", true, false)
			var valid := not meshes.is_empty()
			var skinned := 0
			for node: MeshInstance3D in meshes:
				valid = valid and node.mesh != null and node.mesh.get_surface_count() > 0
				if node.skin != null and node.skin.get_bind_count() >= 11:
					skinned += 1
			if name == "fitted_outfit.glb":
				valid = valid and skinned >= 2 and not skeletons.is_empty()
			if not valid:
				actor.free()
				push_error("Pack contains an incomplete fitted-rider scene: " + path)
				return false
			report.fitted_resources[name] = {"kind": "scene", "mesh_nodes": meshes.size(), "skeletons": skeletons.size(), "skinned_meshes": skinned}
			actor.free()
	return true
func _board_resource(report: Dictionary) -> bool:
	# Read the cooked scene and its data-only import receipt. Editor importers,
	# source decoders and Python generators are intentionally not runtime loads.
	var manifest_path := "res://game/art/assets/tam_skateboard/manifest.json"
	var manifest: Variant = JSON.parse_string(FileAccess.get_file_as_string(manifest_path))
	if not manifest is Dictionary or int(manifest.get("schema", -1)) != 2:
		return _board_failure(null, "Pack is missing readable board UV provenance.")
	if int(manifest.get("meshes", 0)) != 1 or int(manifest.get("surfaces", 0)) != 4 or int(manifest.get("triangles", 0)) != 5696:
		return _board_failure(null, "Pack board provenance has an unsupported resource contract.")
	var path := "res://game/art/assets/tam_skateboard/tam_skateboard.glb"
	var packed: PackedScene = load(path) as PackedScene
	if packed == null:
		return _board_failure(null, "Pack is missing its cooked skateboard scene.")
	var model: Node3D = packed.instantiate() as Node3D
	if model == null:
		return _board_failure(null, "Pack skateboard has no native 3D root.")
	var meta: Dictionary = model.get_meta("tam_board_wood_import", {})
	var outputs: Dictionary = manifest.get("outputs", {})
	var source_record: Dictionary = outputs.get("tam_skateboard.glb", {})
	var editor: Dictionary = manifest.get("editor_import", {})
	if (str(meta.get("source_sha256", "")) != str(source_record.get("sha256", "")) or str(meta.get("source_sha256", "")).length() != 64
			or str(meta.get("policy_sha256", "")) != str(editor.get("policy_sha256", "")) or str(meta.get("policy_sha256", "")).length() != 64
			or str(meta.get("decoder_sha256", "")) != str(editor.get("decoder_sha256", "")) or str(meta.get("decoder_sha256", "")).length() != 64
			or int(meta.get("source_vertices", 0)) != 1600 or int(meta.get("source_indices", 0)) != 7800
			or meta.get("wood_compressed", true) != false or meta.get("protected_packed_surfaces_exact", false) != true or meta.get("protected_shadow_surfaces_exact", false) != true):
		return _board_failure(model, "Cooked board source/editor/decoder receipt differs from packaged provenance.")
	var meshes: Array[MeshInstance3D] = []
	_board_collect(model, meshes)
	if meshes.size() != 1 or model.transform != Transform3D.IDENTITY or meshes[0].transform != Transform3D.IDENTITY:
		return _board_failure(model, "Pack skateboard changed its single-mesh identity frame.")
	var mesh: ArrayMesh = meshes[0].mesh as ArrayMesh
	if mesh == null or mesh.get_surface_count() != 4:
		return _board_failure(model, "Pack skateboard is missing its four native ArrayMesh surfaces.")
	var names: Array[String] = ["MapleAndRiverInk", "Griptape", "CastAluminium", "Urethane"]
	var texture_ids: Dictionary = {}
	var triangles := 0
	var grip_minimum: float = INF
	var wheel_points := PackedVector3Array()
	for surface: int in mesh.get_surface_count():
		var material: StandardMaterial3D = mesh.surface_get_material(surface) as StandardMaterial3D
		if material == null or material.resource_name != names[surface] or material.albedo_texture == null:
			return _board_failure(model, "Pack skateboard material/atlas identity changed.")
		texture_ids[material.albedo_texture.get_instance_id()] = material.albedo_texture
		var arrays: Array = mesh.surface_get_arrays(surface)
		var points: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
		var indices: PackedInt32Array = arrays[Mesh.ARRAY_INDEX]
		if points.is_empty() or indices.is_empty() or indices.size() % 3 != 0:
			return _board_failure(model, "Pack skateboard has incomplete indexed native geometry.")
		triangles += indices.size() / 3
		for index: int in indices:
			if index < 0 or index >= points.size() or not points[index].is_finite():
				return _board_failure(model, "Pack skateboard contains invalid indexed positions.")
		if surface == 0:
			var uv: PackedVector2Array = arrays[Mesh.ARRAY_TEX_UV]
			if indices.size() != 7800 or uv.size() != points.size() or (mesh.surface_get_format(0) & Mesh.ARRAY_FLAG_COMPRESS_ATTRIBUTES) != 0:
				return _board_failure(model, "Pack wood lost source geometry/compression protection.")
			for i: int in range(0, indices.size(), 3):
				var a: Vector2 = uv[indices[i]]
				var b: Vector2 = uv[indices[i + 1]]
				var c: Vector2 = uv[indices[i + 2]]
				if not a.is_finite() or not b.is_finite() or not c.is_finite() or absf((b - a).cross(c - a)) * 0.5 <= 1e-12:
					return _board_failure(model, "Pack wood contains collapsed/nonfinite native UV triangles.")
		elif surface == 1:
			for point: Vector3 in points:
				grip_minimum = minf(grip_minimum, point.y)
		elif surface == 3:
			for point: Vector3 in points:
				if absf(point.x) > 0.09:
					wheel_points.append(point)
	if triangles != 5696 or texture_ids.size() != 1 or not model.find_children("*", "CollisionObject3D", true, false).is_empty():
		return _board_failure(model, "Pack skateboard changed its triangle/atlas/visual-only contract.")
	var contract: Dictionary = manifest.get("contract", {})
	if absf(grip_minimum - float(contract.get("deck_grip_center_y_m", INF))) > 0.000001:
		return _board_failure(model, "Pack board grip datum differs from its physical contract.")
	var wheels: Array = []
	var axles: Array = contract.get("axle_z_m", [])
	if axles.size() != 2:
		return _board_failure(model, "Pack board is missing its two axle datums.")
	for axle: float in axles:
		for side: float in [-1.0, 1.0]:
			var minimum_y: float = INF
			var maximum_y: float = -INF
			var minimum_z: float = INF
			var maximum_z: float = -INF
			var count := 0
			for point: Vector3 in wheel_points:
				if point.x * side <= 0.09 or point.z * signf(axle) <= 0.0:
					continue
				minimum_y = minf(minimum_y, point.y)
				maximum_y = maxf(maximum_y, point.y)
				minimum_z = minf(minimum_z, point.z)
				maximum_z = maxf(maximum_z, point.z)
				count += 1
			if (count < 20 or absf((minimum_y + maximum_y) * 0.5 - float(contract.get("wheel_center_y_m", INF))) > 0.000001
					or absf((maximum_y - minimum_y) * 0.5 - float(contract.get("wheel_radius_m", INF))) > 0.000001
					or absf((minimum_z + maximum_z) * 0.5 - axle) > 0.000001):
				return _board_failure(model, "Pack board native wheel centre/radius/axle contract changed.")
			wheels.append({"side": side, "axle_z": axle, "native_points": count, "minimum_y": minimum_y, "maximum_y": maximum_y})
	var texture: Texture2D = texture_ids.values()[0]
	var image: Image = texture.get_image()
	if (image == null or texture.get_width() != 1024 or texture.get_height() != 1024
			or image.get_format() != Image.FORMAT_RGB8 or image.get_mipmap_count() != 10 or image.get_data().size() != 4194303):
		return _board_failure(model, "Pack board atlas lost its RGB8/mip allocation contract.")
	report.board = {"resource": path, "mesh_nodes": meshes.size(), "surfaces": mesh.get_surface_count(), "triangles": triangles,
		"atlas_resource": texture.resource_path, "atlas_width": texture.get_width(), "atlas_height": texture.get_height(),
		"atlas_format": image.get_format(), "atlas_mipmaps": image.get_mipmap_count(), "atlas_bytes": image.get_data().size(),
		"native_import_receipt": meta, "grip_minimum_y": grip_minimum, "native_wheels": wheels, "editor_tools_required": false}
	model.free()
	return true

func _board_collect(node: Node, meshes: Array[MeshInstance3D]) -> void:
	if node is MeshInstance3D:
		meshes.append(node)
	for child: Node in node.get_children():
		_board_collect(child, meshes)

func _board_failure(model: Node, reason: String) -> bool:
	if is_instance_valid(model):
		model.free()
	push_error(reason)
	return false


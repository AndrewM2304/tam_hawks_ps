extends RefCounted
## Original traffic cone within the existing 0.35 x 0.6 x 0.35m prop envelope.
## Private native/art prototype. No external textures or per-frame construction.
const SIDES:=16
const HALF_BASE:=.175
const BASE_BOTTOM:=-.3
const BASE_TOP:=-.26
const TOP:=.3
const BOTTOM_RADIUS:=.145
const TOP_RADIUS:=.025

static func make(materials:Dictionary)->StaticBody3D:
	var body:=StaticBody3D.new();body.name="MerchantSignCone"
	body.collision_layer=1;body.set_meta("surface_audio","stone");body.set_meta("wallrideable",false)
	var base:=BoxShape3D.new();base.size=Vector3(.35,.04,.35)
	var bottom:=CollisionShape3D.new();bottom.name="NativeBase";bottom.shape=base;bottom.position.y=-.28;body.add_child(bottom)
	var points:=PackedVector3Array()
	for pair:Vector2 in [Vector2(BASE_TOP,BOTTOM_RADIUS),Vector2(TOP,TOP_RADIUS)]:
		for i:int in SIDES:
			var angle:float=TAU*i/SIDES;points.append(Vector3(sin(angle)*pair.y,pair.x,cos(angle)*pair.y))
	var shape:=ConvexPolygonShape3D.new();shape.points=points
	var collision:=CollisionShape3D.new();collision.name="NativeTaper";collision.shape=shape;body.add_child(collision)
	var mesh:=ArrayMesh.new()
	var base_tool:=SurfaceTool.new();base_tool.begin(Mesh.PRIMITIVE_TRIANGLES)
	for axis:int in 3:
		for signum:float in [-1.,1.]:
			var normal:=Vector3.ZERO;normal[axis]=signum
			var a:=Vector3.ZERO;a[(axis+1)%3]=1
			var b:=normal.cross(a)
			var vertices:Array[Vector3]=[]
			for uv:Vector2 in [Vector2(-1,-1),Vector2(1,-1),Vector2(1,1),Vector2(-1,1)]:
				var v:Vector3=normal+a*uv.x+b*uv.y;vertices.append(Vector3(v.x*HALF_BASE,v.y*.02-.28,v.z*HALF_BASE))
			_quad(base_tool,vertices[0],vertices[1],vertices[2],vertices[3],normal,normal)
	_finish(base_tool,mesh,materials.iron)
	for reflective:bool in [false,true]:
		var tool:=SurfaceTool.new();tool.begin(Mesh.PRIMITIVE_TRIANGLES)
		var levels:Array[float]=[BASE_TOP,-.04,.12,TOP]
		for j:int in 3:
			if (j==1)!=reflective:continue
			var low:float=levels[j];var high:float=levels[j+1]
			var low_r:float=_radius(low);var high_r:float=_radius(high)
			for i:int in SIDES:
				var a:float=TAU*i/SIDES;var b:float=TAU*(i+1)/SIDES
				var n1:=Vector3(sin(a),(BOTTOM_RADIUS-TOP_RADIUS)/(TOP-BASE_TOP),cos(a)).normalized()
				var n2:=Vector3(sin(b),(BOTTOM_RADIUS-TOP_RADIUS)/(TOP-BASE_TOP),cos(b)).normalized()
				_quad(tool,Vector3(sin(a)*low_r,low,cos(a)*low_r),Vector3(sin(b)*low_r,low,cos(b)*low_r),
					Vector3(sin(b)*high_r,high,cos(b)*high_r),Vector3(sin(a)*high_r,high,cos(a)*high_r),n1,n2)
		if not reflective:
			for pair:Vector2 in [Vector2(BASE_TOP,-1),Vector2(TOP,1)]:
				for i:int in SIDES:
					var a:float=TAU*i/SIDES;var b:float=TAU*(i+1)/SIDES;var radius:float=_radius(pair.x)
					_triangle(tool,Vector3(0,pair.x,0),Vector3(sin(a)*radius,pair.x,cos(a)*radius),Vector3(sin(b)*radius,pair.x,cos(b)*radius),Vector3.UP*pair.y)
		_finish(tool,mesh,materials.window_frame if reflective else materials.orange)
	var visible:=MeshInstance3D.new();visible.name="NativeCone";visible.mesh=mesh;body.add_child(visible)
	return body

static func _radius(y:float)->float:return lerpf(BOTTOM_RADIUS,TOP_RADIUS,(y-BASE_TOP)/(TOP-BASE_TOP))

static func minimum_y(basis:Basis)->float:
	var lowest:=INF
	for x:float in [-HALF_BASE,HALF_BASE]:
		for y:float in [BASE_BOTTOM,BASE_TOP]:
			for z:float in [-HALF_BASE,HALF_BASE]:lowest=minf(lowest,(basis*Vector3(x,y,z)).y)
	for pair:Vector2 in [Vector2(BASE_TOP,BOTTOM_RADIUS),Vector2(TOP,TOP_RADIUS)]:
		for i:int in SIDES:
			var angle:float=TAU*i/SIDES;lowest=minf(lowest,(basis*Vector3(sin(angle)*pair.y,pair.x,cos(angle)*pair.y)).y)
	return lowest

static func _quad(t:SurfaceTool,a:Vector3,b:Vector3,c:Vector3,d:Vector3,n1:Vector3,n2:Vector3)->void:
	# Winding is clockwise viewed from outside; radial normals remain smooth.
	var points:Array[Vector3]=[a,b,c,a,c,d];var normals:Array[Vector3]=[n1,n2,n2,n1,n2,n1]
	if (b-a).cross(c-a).dot(n1+n2)>0:
		points=[a,c,b,a,d,c];normals=[n1,n2,n2,n1,n1,n2]
	for i:int in points.size():t.set_normal(normals[i]);t.set_uv(Vector2(points[i].x,points[i].y));t.add_vertex(points[i])

static func _triangle(t:SurfaceTool,a:Vector3,b:Vector3,c:Vector3,n:Vector3)->void:
	var points:Array[Vector3]=[a,b,c]
	if (b-a).cross(c-a).dot(n)>0:points=[a,c,b]
	for v:Vector3 in points:t.set_normal(n);t.set_uv(Vector2(v.x,v.z));t.add_vertex(v)

static func _finish(t:SurfaceTool,mesh:ArrayMesh,material:Material)->void:
	t.index();t.generate_tangents();t.commit(mesh);mesh.surface_set_material(mesh.get_surface_count()-1,material)

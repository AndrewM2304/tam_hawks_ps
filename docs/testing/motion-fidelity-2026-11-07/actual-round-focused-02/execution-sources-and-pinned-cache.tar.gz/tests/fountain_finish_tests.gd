extends RefCounted
## PT24-26: the original shared water finish must not alter basin/contact data.

static func run(tree: SceneTree, game: Node, check: Callable) -> void:
	await tree.physics_frame
	var world: Node3D = game.world
	var body: StaticBody3D = world.get_node("ExchangeFountain")
	var water: MeshInstance3D = body.get_node("FountainWater")
	var basin: MeshInstance3D = body.get_node("FountainBasin")
	var river: MeshInstance3D = world.get_node("OutdoorRoutes/ClydeWater")
	var pond: MeshInstance3D = world.get_node("KelvingrovePond/PondWater")
	check.call(water.material_override is ShaderMaterial and water.material_override == river.material_override
		and water.material_override == pond.material_override,
		"PT24 fountain finish: fountain, pond and river share one existing water material")
	var water_mesh := water.mesh as CylinderMesh
	var basin_mesh: Mesh = basin.mesh
	var basin_info:=_basin_surface_info(basin_mesh)
	check.call(body.position == Vector3(0,0,10) and water.position == Vector3(0,.55,0)
		and water_mesh.radial_segments == 64 and water_mesh.rings == 0
		and is_equal_approx(water_mesh.top_radius,5.96) and is_equal_approx(water_mesh.bottom_radius,5.96)
		and is_equal_approx(water_mesh.height,.01) and basin_mesh is ArrayMesh and is_equal_approx(basin_mesh.get_aabb().size.x*.5,6.2),
		"PT24 fountain finish: existing circular water mesh, height and coping margin remain exact")
	check.call(basin_info.source_triangles==512 and basin_info.top_triangles==128 and basin_info.floor_triangles==64
		and basin_info.outer_boundary_vertices==64 and basin_info.inner_boundary_vertices==64 and basin_info.annulus_radii_valid,
		"fountain finish: actual512triangle hollow basin has64sector annulus and upwardfloor instead of a hidden top disk")
	check.call(water.cast_shadow==GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		and river.cast_shadow==GeometryInstance3D.SHADOW_CASTING_SETTING_OFF and pond.cast_shadow==GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		and basin.cast_shadow==GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		and not (basin.material_override as StandardMaterial3D).disable_receive_shadows
		and not (water.material_override as ShaderMaterial).shader.code.contains("shadows_disabled"),
		"fountain finish: all exact water casters areoff while stone casting and real shadow reception remain")
	var contained := true
	var vertices := 0
	for p: Vector3 in water_mesh.get_faces():
		vertices += 1
		contained = contained and Vector2(p.x,p.z).length() < 5.961 and p.y <= .00501 and p.y >= -.00501
	check.call(contained and vertices == 768,
		"PT24 fountain finish: all 768 original water face vertices retain their fixed basin footprint")
	var shapes: Array[CollisionShape3D] = []
	for child: Node in body.get_children():
		if child is CollisionShape3D: shapes.append(child)
	check.call(shapes.size() == 2 and shapes[0].shape is CylinderShape3D
		and is_equal_approx(shapes[0].shape.radius,6.2) and is_equal_approx(shapes[0].shape.height,.55)
		and is_equal_approx(shapes[0].position.y,.275)
		and shapes[1].shape is CylinderShape3D and is_equal_approx(shapes[1].shape.radius,.7)
		and is_equal_approx(shapes[1].shape.height,2.7) and is_equal_approx(shapes[1].position.y,1.35),
		"PT24 fountain finish: both original basin and pedestal native shapes remain exact")
	var native := true
	var safe := true
	var space := world.get_world_3d().direct_space_state
	for sample: int in 32:
		var angle := float(sample) * TAU / 32.0
		var at := Vector3(cos(angle)*5.4,1.4,10+sin(angle)*5.4)
		var hit := space.intersect_ray(PhysicsRayQueryParameters3D.create(at,at-Vector3.UP*1.3,1))
		native = native and not hit.is_empty() and hit.collider == body and absf(hit.position.y-.55)<.001
		safe = safe and not world.get_recovery_position(Vector3(at.x,.55,at.z)).is_finite()
	check.call(native,"PT24 fountain finish: 32 native basin contacts keep their unchanged .55m support")
	check.call(safe,"PT24 fountain finish: the existing fountain has no new water-recovery trigger")
	var guides: Array = world.get_grind_lines().filter(func(line): return line.id == "Grind_Coping_ExchangeFountain")
	var guide_ok := guides.size() == 1
	if guide_ok:
		var line = guides[0]
		guide_ok = line.is_valid and line.is_loop and line.kind == "coping" and line.points.size() == 65
		for point: Vector3 in line.points:
			guide_ok = guide_ok and absf(point.y-.92)<.00001 and absf(Vector2(point.x,point.z-10).length()-6.2)<.00001
	check.call(guide_ok,"PT24 fountain finish: original closed coping ID and all 65 authored guide points remain")

static func _basin_surface_info(mesh: Mesh) -> Dictionary:
	var arrays:=mesh.surface_get_arrays(0)
	var positions: PackedVector3Array=arrays[Mesh.ARRAY_VERTEX]
	var indices: PackedInt32Array=arrays[Mesh.ARRAY_INDEX]
	var top:=0
	var floor_count:=0
	var outer: Dictionary={}
	var inner: Dictionary={}
	var annulus_radii_valid:=true
	for offset: int in range(0,indices.size(),3):
		# Mesh.get_faces() snaps coordinates; inspect the exact referenced streams.
		var a:=positions[indices[offset]]
		var b:=positions[indices[offset+1]]
		var c:=positions[indices[offset+2]]
		if absf(a.y-.275)<.00001 and absf(b.y-.275)<.00001 and absf(c.y-.275)<.00001:
			top+=1
			for point: Vector3 in [a,b,c]:
				var radius:=Vector2(point.x,point.z).length()
				var key:=Vector2i(roundi(point.x*10000.0),roundi(point.z*10000.0))
				annulus_radii_valid=annulus_radii_valid and radius>=5.9599 and radius<=6.2001
				if absf(radius-6.2)<.00001:outer[key]=true
				elif absf(radius-5.96)<.00001:inner[key]=true
		elif absf(a.y+.225)<.00001 and absf(b.y+.225)<.00001 and absf(c.y+.225)<.00001:floor_count+=1
	return {"source_triangles":indices.size()/3,"top_triangles":top,"floor_triangles":floor_count,"outer_boundary_vertices":outer.size(),"inner_boundary_vertices":inner.size(),"annulus_radii_valid":annulus_radii_valid}

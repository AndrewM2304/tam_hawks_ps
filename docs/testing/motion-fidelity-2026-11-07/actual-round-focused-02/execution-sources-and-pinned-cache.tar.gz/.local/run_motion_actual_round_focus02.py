from pathlib import Path
import datetime,hashlib,json,os,re,signal,subprocess,time
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'.local/motion-actual-round-focus-02'
OUT.mkdir(exist_ok=False)
OBSERVER=ROOT/'.local/motion_actual_round_focus02.gd'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sources():
 files=[OBSERVER,ROOT/'.local/motion_round_registry_helper.gd',Path(__file__).resolve(),ROOT/'project.godot',ROOT/'export_presets.cfg',ROOT/'docs/PLAYER-GUIDE.md']
 missing=[str(p) for p in files if not p.is_file()]
 if missing:raise RuntimeError('Missing REQUIRED source binding inputs: '+repr(missing))
 for directory in ['game','tests','tools','docs/licences']:
  if not (ROOT/directory).is_dir():raise RuntimeError('Missing REQUIRED source directory: '+directory)
  files +=[p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
 return {str(p.relative_to(ROOT)):sha(p) for p in sorted(set(files))}
def cachepins():
 files=[]
 for rel in ['game/art/assets/tam_skateboard/tam_skateboard.glb.import','.godot/global_script_class_cache.cfg','.godot/uid_cache.bin']:
  if not (ROOT/rel).is_file():raise RuntimeError('Missing REQUIRED native-cache binding: '+rel)
  files.append(ROOT/rel)
 for p in (ROOT/'.godot/imported').glob('tam_skateboard.glb-*'):
  if p.is_file():files.append(p)
 if not any(p.suffix=='.scn' for p in files):raise RuntimeError('Missing REQUIRED cooked native board scene')
 return {str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}
before=sources();cache_before=cachepins();epochs=[];deadline=time.monotonic()+180
env=os.environ.copy();env['TAM_ACTUAL_ROUND_FOCUS_RESULT']=str(OUT/'result.json');env['TAM_ACTUAL_ROUND_REGISTRY_RESULT']=str(OUT/'public-registry.json')
for label,flags,cap in [('parser',['--check-only'],5),('native',['--fixed-fps','60'],175)]:
 command=[str(ROOT/'tools/run.sh'),'--headless']+flags+['--script','res://.local/motion_actual_round_focus02.gd']
 log=OUT/(label+'.log');record={'name':label,'command':command,'start':now(),'cap_seconds':cap};stop=None
 with log.open('wb') as stream:
  proc=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True,env=env)
  record['pid']=proc.pid;print(json.dumps(record),flush=True)
  end=min(deadline,time.monotonic()+cap);position=0;carry=b''
  while proc.poll() is None:
   with log.open('rb') as incoming:incoming.seek(position);chunk=incoming.read();position=incoming.tell()
   data=carry+chunk;carry=data[-300:]
   if re.search(rb'ERROR:|Parse Error:',data):stop='first raw engine error';break
   if time.monotonic()>end:stop='automatic bounded diagnostic deadline';break
   time.sleep(.05)
  if proc.poll() is None:
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=1)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 record.update({'end':now(),'exit':proc.returncode,'stop':stop,'log_sha256':sha(log),'raw_errors':bool(re.search(r'ERROR:|Parse Error:',log.read_text()))});epochs.append(record)
 if stop or record['raw_errors'] or (label=='parser' and proc.returncode!=0):break
after=sources();cache_after=cachepins();result=json.loads((OUT/'result.json').read_text()) if (OUT/'result.json').exists() else None
execution_finished=result is not None and all(e['stop'] is None for e in epochs)
complete=(execution_finished and before==after and cache_before==cache_after
          and all(e['exit']==0 and not e['raw_errors'] for e in epochs))
eligible=complete and result['failed']==0
receipt={'epochs':epochs,'source_before':before,'source_after':after,'source_stable':before==after,
         'cache_before':cache_before,'cache_after':cache_after,'cache_stable':cache_before==cache_after,
         'result':result,'execution_finished':execution_finished,'complete':complete,'eligible':eligible,
         'eligibility_rule':'Result present, every parser/native exit0, no timeout/rawERROR, stable required source+cache bindings, zero failed assertions.',
         'scope':'Actual read-only focused modules; mandatory actual game/tests/tools/licences/project/export/docs/PLAYER-GUIDE.md and observer/launcher/helper before+after. Board import metadata/cooked binary+UID/class cache pins independent. No edits/imports/GPU/performance claim.'}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if not isinstance(v,dict) or k in ['result']},indent=2),flush=True)
raise SystemExit(0 if receipt['eligible'] else 1)

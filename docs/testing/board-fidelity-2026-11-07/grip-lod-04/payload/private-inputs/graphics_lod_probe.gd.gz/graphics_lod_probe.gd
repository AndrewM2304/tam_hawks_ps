extends SceneTree
var output:String
var _native_size:=Vector2i(1280,800)
var _raw_spool:=false
var checks:=0
var failures:=0
var _proof_markers:Array[MeshInstance3D]=[]
var _proof_swatch:ColorRect
var _active_proof_camera:Camera3D
func _initialize()->void:run.call_deferred()
func _render_current_frame() -> Image:
	# Let the engine flush current Node3D, Skeleton and Canvas notifications in
	# its normal render pass. Manual force_draw immediately after changing the
	# camera can read the previous camera, even when metadata is already current.
	var native_tick := Engine.get_physics_frames()
	var process_tick := Engine.get_process_frames()
	var started := Time.get_ticks_usec()
	RenderingServer.set_render_loop_enabled(true)
	await RenderingServer.frame_post_draw
	RenderingServer.set_render_loop_enabled(false)
	_check(Engine.get_physics_frames() == native_tick and Engine.get_process_frames() == process_tick,
		"natural readback completes the current frame without another physics/process tick")
	var image := root.get_texture().get_image()
	image.convert(Image.FORMAT_RGBA8)
	_check(image.get_width() == _native_size.x and image.get_height() == _native_size.y,
		"native capture retains every pixel of its declared "+str(_native_size)+" viewport")
	image.set_meta("draw_and_read_microseconds", Time.get_ticks_usec() - started)
	return image

func _store_frame(image: Image, relative: String) -> Dictionary:
	var started := Time.get_ticks_usec()
	var bytes := image.get_data()
	var hash := HashingContext.new()
	hash.start(HashingContext.HASH_SHA256)
	hash.update(bytes)
	var pixel_hash := hash.finish().hex_encode()
	if _raw_spool:
		var raw_path := output.path_join(relative.get_basename() + ".rgba")
		var file := FileAccess.open(raw_path + ".tmp", FileAccess.WRITE)
		_check(file != null, "raw pixel spool opened " + relative)
		if file != null:
			file.store_buffer(bytes)
			file.close()
			_check(DirAccess.rename_absolute(raw_path + ".tmp", raw_path) == OK,
				"complete native pixel spool published atomically " + relative)
	else:
		_check(image.save_png(output.path_join(relative)) == OK, "lossless frame saved " + relative)
	return {"format":"RGBA8", "rgba8_sha256":pixel_hash, "bytes":bytes.size(),
		"draw_and_read_microseconds":image.get_meta("draw_and_read_microseconds", 0),
		"hash_and_store_microseconds":Time.get_ticks_usec() - started,
		"encoding":"atomic raw spool to standard-library lossless PNG" if _raw_spool else "Godot lossless PNG"}

func _v(point: Vector3) -> Array:
	return [point.x, point.y, point.z]

func _v4(value: Vector4) -> Array:
	return [value.x,value.y,value.z,value.w]

func _check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		push_error("FAIL: " + label)

func _create_pixel_proofs() -> void:
	for color: Color in [Color.RED,Color.GREEN]:
		var mesh := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = 0.055
		sphere.height = 0.11
		sphere.radial_segments = 12
		sphere.rings = 6
		mesh.mesh = sphere
		var material := StandardMaterial3D.new()
		material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		material.albedo_color = color
		material.no_depth_test = true
		mesh.material_override = material
		mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(mesh)
		_proof_markers.append(mesh)
	var canvas := CanvasLayer.new()
	root.add_child(canvas)
	_proof_swatch = ColorRect.new()
	_proof_swatch.position = Vector2(4,4)
	_proof_swatch.size = Vector2(18,18)
	canvas.add_child(_proof_swatch)

func _verify_pixel_proofs(image: Image) -> Dictionary:
	var records: Array[Dictionary] = []
	for index: int in _proof_markers.size():
		var point := _proof_markers[index].global_position
		var projected := _active_proof_camera.unproject_position(point)
		var center := Vector2.ZERO
		var count := 0
		for y: int in range(maxi(0,int(projected.y)-10),mini(image.get_height(),int(projected.y)+11)):
			for x: int in range(maxi(0,int(projected.x)-10),mini(image.get_width(),int(projected.x)+11)):
				var color := image.get_pixel(x,y)
				var found := color.r>0.75 and color.r-color.g>0.20 and color.r-color.b>0.20 if index==0 else color.g>0.75 and color.g-color.r>0.20 and color.g-color.b>0.20
				if found: center+=Vector2(x+0.5,y+0.5);count+=1
		if count: center/=float(count)
		var error := center.distance_to(projected)
		_check(count>=8 and error<=2.0,"projected independent3D marker matches actual pixels")
		records.append({"color":"red" if index==0 else "green","world_position":_v(point),"projected_xy":[projected.x,projected.y],"pixel_count":count,"centroid_xy":[center.x,center.y],"error_pixels":error})
	var expected := _proof_swatch.color
	var actual := image.get_pixel(10,10)
	var swatch_error := maxf(absf(expected.r-actual.r),maxf(absf(expected.g-actual.g),absf(expected.b-actual.b)))
	_check(swatch_error<=2.0/255.0,"current Canvas material/view swatch agrees with native pixels")
	return {"markers":records,"canvas_expected_rgb":[expected.r,expected.g,expected.b],"canvas_actual_rgb":[actual.r,actual.g,actual.b],"canvas_error":swatch_error,"canvas_sample_xy":[10,10]}


func run()->void:
	var args:=OS.get_cmdline_user_args();output=args[0];var mode:String=args[1]
	root.size=_native_size;root.content_scale_size=_native_size;RenderingServer.set_render_loop_enabled(false)
	var sky_mat:=ProceduralSkyMaterial.new();sky_mat.sky_top_color=Color("8e9eaa");sky_mat.sky_horizon_color=Color("c4c8c4");sky_mat.ground_horizon_color=Color("c4c8c4")
	var sky:=Sky.new();sky.sky_material=sky_mat
	var env:=Environment.new();env.background_mode=Environment.BG_SKY;env.sky=sky;env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;env.ambient_light_energy=.36;env.ambient_light_color=Color("d0dce2");env.tonemap_mode=Environment.TONE_MAPPER_ACES
	var environment:=WorldEnvironment.new();environment.environment=env;root.add_child(environment)
	var light:=DirectionalLight3D.new();light.rotation_degrees=Vector3(-48,-32,0);light.light_energy=.86;light.shadow_enabled=true;light.directional_shadow_mode=DirectionalLight3D.SHADOW_ORTHOGONAL;root.add_child(light)
	var packed:PackedScene=load("res://baseline_board.scn"if mode=="baseline"else"res://game/art/assets/tam_skateboard/tam_skateboard.glb")as PackedScene
	var model:Node3D=packed.instantiate();root.add_child(model)
	var meshes:Array=model.find_children("*","MeshInstance3D",true,false);_check(meshes.size()==1,"actual single native board mesh")
	var lod:float=float(args[2]);meshes[0].lod_bias=lod
	var mesh:ArrayMesh=meshes[0].mesh;var triangles:=0;var textures:Dictionary={}
	for i:int in mesh.get_surface_count():
		triangles+=mesh.surface_get_arrays(i)[Mesh.ARRAY_INDEX].size()/3
		var mat:StandardMaterial3D=mesh.surface_get_material(i)as StandardMaterial3D;textures[mat.albedo_texture.get_instance_id()]=mat.albedo_texture
	_check(triangles==(5696 if mode=="baseline"else 5996),"exact intended native triangle count")
	_check(mesh.get_surface_count()==4 and textures.size()==1,"same four surfaces and one shared atlas")
	var wheel_bottom:float=INF
	var wheel_arrays:Array=mesh.surface_get_arrays(3)
	var wheel_vertices:PackedVector3Array=wheel_arrays[Mesh.ARRAY_VERTEX]
	for index:int in wheel_arrays[Mesh.ARRAY_INDEX]:
		if absf(wheel_vertices[index].x)>.09:wheel_bottom=minf(wheel_bottom,wheel_vertices[index].y)
	model.position.y=-wheel_bottom
	_check(absf(model.position.y+wheel_bottom)<.000001,"viewer aligns actual indexed tyre bottom to zero floor")
	var floor:=MeshInstance3D.new();var plane:=PlaneMesh.new();plane.size=Vector2(4,4);floor.mesh=plane;floor.position.y=0.0
	var floor_mat:=StandardMaterial3D.new();floor_mat.albedo_color=Color("777b7b");floor_mat.roughness=.9;floor.material_override=floor_mat;root.add_child(floor)
	_active_proof_camera=Camera3D.new();_active_proof_camera.near=.005;_active_proof_camera.far=20;_active_proof_camera.fov=42;root.add_child(_active_proof_camera);_active_proof_camera.current=true;_create_pixel_proofs()
	var views:Array[Dictionary]=[{"id":"ride_quarter","at":Vector3(.72,.55,1.05),"to":Vector3(0,-.02,0),"floor":true},{"id":"side_construction","at":Vector3(.98,.10,.12),"to":Vector3(0,-.025,0),"floor":true},{"id":"underside","at":Vector3(.55,-.55,.78),"to":Vector3(0,-.025,0),"floor":false}]
	var images:Array=[]
	for i:int in views.size():
		var view:Dictionary=views[i];floor.visible=view.floor;_active_proof_camera.position=view.at+Vector3.UP*.12;_active_proof_camera.look_at(view.to+Vector3.UP*.12)
		_proof_markers[0].global_position=_active_proof_camera.to_global(Vector3(-2,1.3,-5));_proof_markers[1].global_position=_active_proof_camera.to_global(Vector3(2,1,-5));_proof_swatch.color=Color8(20,35+35*i,190)
		await process_frame;await create_timer(0.0,true).timeout
		var image:Image=await _render_current_frame();var proof:Dictionary=_verify_pixel_proofs(image);var name:String=str(view.id)+".png";var projection:Projection=_active_proof_camera.get_camera_projection()
		images.append({"file":name,"pixels":_store_frame(image,name),"proofs":proof,"camera_position":_v(_active_proof_camera.position),"camera_basis":[_v(_active_proof_camera.global_basis.x),_v(_active_proof_camera.global_basis.y),_v(_active_proof_camera.global_basis.z)],"projection":[_v4(projection.x),_v4(projection.y),_v4(projection.z),_v4(projection.w)],"draws":Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),"primitives":Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME),"buffer_bytes":Performance.get_monitor(Performance.RENDER_BUFFER_MEM_USED),"texture_bytes":Performance.get_monitor(Performance.RENDER_TEXTURE_MEM_USED)})
	var f:=FileAccess.open(output.path_join("views.json"),FileAccess.WRITE);f.store_string(JSON.stringify({"native_wheel_bottom_m":wheel_bottom,"viewer_root_y_m":model.position.y,"mode":mode,"instance_lod_bias":lod,"checks":checks,"failures":failures,"triangles":triangles,"images":images,"scope":"Actual native single board static construction/tyre/floor/underside comparison. Observer fixtures, no Main/pose/motion or M5 acceptance."},"\t")+"\n");f.close();print("BOARD_STATIC_VIEWS: ",checks-failures," passed, ",failures," failed");quit(1 if failures else 0)

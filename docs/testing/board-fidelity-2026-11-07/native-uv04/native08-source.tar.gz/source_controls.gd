extends RefCounted
const Policy=preload("res://tools/art/board_wood_source.gd")
static func run(check:Callable)->void:
 var policy:RefCounted=Policy.new()
 var source:PackedByteArray=FileAccess.get_file_as_bytes("res://candidate/tam_skateboard.glb")
 var decoded:Dictionary=policy.decode_source(source,Policy.SOURCE_SHA)
 check.call(not decoded.is_empty() and decoded.arrays[Mesh.ARRAY_VERTEX].size()==1600,"source policy actual pinned raw wood decodes")
 check.call(policy.decode_source(source,"0".repeat(64)).is_empty(),"source policy wrong source pin refuses before geometry")
 var altered:PackedByteArray=source.duplicate()
 altered[altered.size()-10]^=1
 check.call(policy.decode_source(altered,Policy.SOURCE_SHA).is_empty(),"source policy changed source bytes refuse original pin")
 var json_size:int=source.decode_u32(12)
 var json_data:Dictionary=JSON.parse_string(source.slice(20,20+json_size).get_string_from_utf8())
 var binary_start:int=20+json_size+8
 var binary:PackedByteArray=source.slice(binary_start,binary_start+source.decode_u32(20+json_size))
 var layout:Dictionary=json_data.duplicate(true)
 layout.meshes[0].primitives[0].material=1
 var wrong_layout:PackedByteArray=_pack(layout,binary)
 check.call(policy.decode_source(wrong_layout,policy._sha(wrong_layout)).is_empty(),"source policy rehashed wrong primitive layout refuses")
 var stride:Dictionary=json_data.duplicate(true)
 var position_index:int=int(stride.meshes[0].primitives[0].attributes.POSITION)
 stride.bufferViews[int(stride.accessors[position_index].bufferView)]["byteStride"]=16
 var wrong_stride:PackedByteArray=_pack(stride,binary)
 check.call(policy.decode_source(wrong_stride,policy._sha(wrong_stride)).is_empty(),"source policy rehashed unsupported interleaving refuses")
 var nonfinite:PackedByteArray=binary.duplicate()
 var accessor:Dictionary=json_data.accessors[position_index]
 var at:int=int(json_data.bufferViews[int(accessor.bufferView)].get("byteOffset",0))+int(accessor.get("byteOffset",0))
 nonfinite.encode_float(at,NAN)
 var bad_position:PackedByteArray=_pack(json_data,nonfinite)
 check.call(policy.decode_source(bad_position,policy._sha(bad_position)).is_empty(),"source policy rehashed nonfinite actual source position refuses")
 var bad_indices:PackedByteArray=binary.duplicate()
 var index_accessor:Dictionary=json_data.accessors[int(json_data.meshes[0].primitives[0].indices)]
 var index_at:int=int(json_data.bufferViews[int(index_accessor.bufferView)].get("byteOffset",0))+int(index_accessor.get("byteOffset",0))
 if int(index_accessor.componentType)==5123:bad_indices.encode_u16(index_at,65535)
 else:bad_indices.encode_u32(index_at,65535)
 var invalid_index:PackedByteArray=_pack(json_data,bad_indices)
 check.call(policy.decode_source(invalid_index,policy._sha(invalid_index)).is_empty(),"source policy rehashed out-of-range source index refuses")
static func _pack(gltf:Dictionary,binary:PackedByteArray)->PackedByteArray:
 var json_bytes:PackedByteArray=JSON.stringify(gltf,"",true,true).to_utf8_buffer()
 while json_bytes.size()%4:json_bytes.append(32)
 var result:=PackedByteArray();result.resize(20)
 result.encode_u32(0,0x46546c67);result.encode_u32(4,2)
 result.encode_u32(8,28+json_bytes.size()+binary.size())
 result.encode_u32(12,json_bytes.size());result.encode_u32(16,0x4e4f534a)
 result.append_array(json_bytes)
 var offset:int=result.size();result.resize(offset+8)
 result.encode_u32(offset,binary.size());result.encode_u32(offset+4,0x004e4942)
 result.append_array(binary)
 return result

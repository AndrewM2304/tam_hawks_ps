extends SceneTree
## PRIVATE actual editor-imported indexed board/component snapshot.
const Clearance=preload("res://game/tricks/grind_clearance.gd")
const SourceControls=preload("res://source_controls.gd")
var passes:int=0
var failures:Array[String]=[]
func _initialize()->void:_run.call_deferred()
func _check(ok:bool,label:String)->void:
 if ok:passes+=1
 else:failures.append(label)
 print("PASS " if ok else "FAIL ",label)
func _collect(node:Node,meshes:Array[MeshInstance3D])->void:
 if node is MeshInstance3D:meshes.append(node)
 for child:Node in node.get_children():_collect(child,meshes)
func _bytes(value:Variant)->Dictionary:
 if value==null:return {"available":false}
 return {"available":true,"count":value.size(),"base64":Marshalls.raw_to_base64(value.to_byte_array())}
func _run()->void:
 SourceControls.run(_check)
 var records:Array=[]
 for label:String in ["baseline","candidate"]:
  var packed:PackedScene=load("res://"+label+"/tam_skateboard.glb") as PackedScene
  _check(packed!=null,label+" actual imported PackedScene loads")
  if packed==null:continue
  var config:=ConfigFile.new()
  var config_error:Error=config.load("res://"+label+"/tam_skateboard.glb.import")
  var expected_params:Dictionary={"meshes/ensure_tangents":true,"meshes/generate_lods":true,"meshes/create_shadow_meshes":true,"meshes/force_disable_compression":false,"gltf/naming_version":2,"gltf/embedded_image_handling":1}
  expected_params["meshes/force_disable_compression"]=false
  var import_params:Dictionary={}
  var params_match:bool=config_error==OK
  for key:String in expected_params:
   if not config.has_section_key("params",key):params_match=false;continue
   import_params[key]=config.get_value("params",key)
   params_match=params_match and import_params[key]==expected_params[key]
  _check(params_match,label+" actual scene import settings match protected source policy")
  var stage:=Node3D.new()
  root.add_child(stage)
  var model:Node3D=packed.instantiate()
  stage.add_child(model)
  if label=="candidate":
   _check(model.has_meta("tam_board_wood_import") and model.get_meta("tam_board_wood_import",{}).get("source_sha256","")=="76103e39e5ed91c5c8381d38c58af8272915952f000ba475dbda30206b7d0943","candidate actual packed scene retains authenticated source import receipt")
  if label=="candidate":
   var policy_meta:Dictionary=model.get_meta("tam_board_wood_import",{})
   _check(policy_meta.get("policy_sha256","")==FileAccess.get_sha256("res://tools/art/import_board_wood.gd") and policy_meta.get("decoder_sha256","")==FileAccess.get_sha256("res://tools/art/board_wood_source.gd"),"candidate actual executed import policy and decoder hashes match current frozen source")
  var meshes:Array[MeshInstance3D]=[]
  _collect(model,meshes)
  _check(meshes.size()==1,label+" actual source has exactly one MeshInstance")
  var surfaces:Array=[]
  var textures:Dictionary={}
  var materials:Dictionary={}
  var triangles:int=0
  for mesh:MeshInstance3D in meshes:
   _check(mesh.global_transform==Transform3D.IDENTITY,label+" imported mesh preserves identity transform")
   for surface:int in mesh.mesh.get_surface_count():
    var arrays:Array=mesh.mesh.surface_get_arrays(surface)
    var indices:PackedInt32Array=arrays[Mesh.ARRAY_INDEX]
    var positions:PackedVector3Array=arrays[Mesh.ARRAY_VERTEX]
    var normals:PackedVector3Array=arrays[Mesh.ARRAY_NORMAL]
    var uv:PackedVector2Array=arrays[Mesh.ARRAY_TEX_UV]
    var material:StandardMaterial3D=mesh.mesh.surface_get_material(surface) as StandardMaterial3D
    _check(material!=null,label+" actual StandardMaterial surface "+str(surface))
    if material==null:continue
    materials[material.get_instance_id()]=true
    var texture:Texture2D=material.albedo_texture
    if texture!=null:textures[texture.get_instance_id()]={"width":texture.get_width(),"height":texture.get_height(),"resource_path":texture.resource_path}
    triangles+=indices.size()/3
    surfaces.append({"index":surface,"material":material.resource_name,"positions":_bytes(positions),"normals":_bytes(normals),"uv":_bytes(uv),"tangents":_bytes(arrays[Mesh.ARRAY_TANGENT]),"indices":_bytes(indices),"mesh_instance":str(mesh.name),"imported_surface_format":mesh.mesh.surface_get_format(surface),"packed_surface":_packed_surface(mesh.mesh.get("_surfaces")[surface]),"packed_shadow_surface":_packed_surface(mesh.mesh.shadow_mesh.get("_surfaces")[surface])})
  var body:=CharacterBody3D.new()
  root.add_child(body)
  var clearance:=Clearance.new()
  _check(clearance.rebuild(stage,{"meshes":meshes},body.get_rid()),label+" exact existing native component constructor succeeds")
  var parts:Array=[]
  for part:Dictionary in clearance._parts:parts.append({"points":_bytes(part.points),"shape_class":part.shape.get_class(),"margin":part.shape.margin})
  _check(surfaces.size()==4 and materials.size()==4,label+" actual four surfaces/materials retained")
  _check(triangles==5696,label+" actual5696 indexed triangles retained")
  _check(textures.size()==1 and textures.values()[0].width==1024 and textures.values()[0].height==1024,label+" actual one1024atlas shared across all four materials")
  records.append({"label":label,"import_params":import_params,"surfaces":surfaces,"textures":textures.values(),"component_count":clearance.component_count,"component_parts":parts,"edge_roll_angle":clearance.edge_roll_angle,"model_radius":clearance.model_radius,"component_scope":"actual existing GrindClearance constructor, including its inherited get_faces weld policy; indexed rendered buffers exported separately"})
  body.free()
  stage.free()
 if records.size()==2:
  _check(records[0].component_count==records[1].component_count,label_from_count(records)+" no added native cached component")
  _check(records[0].edge_roll_angle==records[1].edge_roll_angle,"actual native edge roll datum unchanged")
  _check(records[0].model_radius==records[1].model_radius,"actual native full-model radius unchanged")
 FileAccess.open("res://native-result.json",FileAccess.WRITE).store_string(JSON.stringify({"passes":passes,"failures":failures,"records":records,"scope":"actual isolated editor-imported buffer/resource/component proof; no rendered/Main/contact/M5 acceptance"},"",true,true))
 print("BOARD_NATIVE_COMPONENT_RESULT ",passes,"/",failures.size())
 quit(0 if failures.is_empty() else 1)
func label_from_count(records:Array)->String:
 return "baseline"+str(records[0].component_count)+" candidate"+str(records[1].component_count)

func _sha_bytes(bytes:PackedByteArray)->String:
 var context:=HashingContext.new();context.start(HashingContext.HASH_SHA256);context.update(bytes);return context.finish().hex_encode()
func _packed_surface(data:Dictionary)->Dictionary:
 var result:Dictionary={"format":data.format,"vertex_count":data.vertex_count,"index_count":data.get("index_count",0)}
 for key:String in ["vertex_data","attribute_data","skin_data","index_data"]:
  if data.has(key):result[key]={"bytes":data[key].size(),"sha256":_sha_bytes(data[key])}
 var lods:Array=data.get("lods",[])
 var record:Array=[]
 for i:int in range(0,lods.size(),2):record.append({"edge_length":float(lods[i]),"index_sha256":_sha_bytes(lods[i+1]),"bytes":lods[i+1].size()})
 result["lods"]=record
 return result

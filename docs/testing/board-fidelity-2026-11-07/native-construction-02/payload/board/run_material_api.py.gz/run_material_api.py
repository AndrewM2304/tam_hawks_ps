from pathlib import Path
import subprocess,datetime,os,hashlib,json,re,signal,time
R=Path(__file__).resolve().parent;P=R/'physical-project';O=R/'material-api-01';O.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files=[Path(__file__).resolve(),P/'material_api_probe.gd',P/'game/art/board_contact_definition.gd'];before={str(p.relative_to(R)):sha(p)for p in files};(O/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');(O/'launcher.py.txt').write_bytes(Path(__file__).read_bytes());env=dict(os.environ)
for kind in ['DATA','CONFIG','CACHE']:
 q=O/('xdg-'+kind.lower());q.mkdir();env['XDG_'+kind+'_HOME']=str(q)
cmd=['/usr/local/bin/godot','--headless','--audio-driver','Dummy','--path',str(P),'--script','res://material_api_probe.gd'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();stop=None
with(O/'native.log').open('w')as f:
 proc=subprocess.Popen(cmd,cwd=P,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);print(json.dumps({'pid':proc.pid,'start':start,'bound_seconds':10}),flush=True)
 try:code=proc.wait(timeout=10)
 except subprocess.TimeoutExpired:stop='10sdeadline';os.killpg(proc.pid,signal.SIGTERM);code=proc.wait(timeout=3)
raw=(O/'native.log').read_text();after={str(p.relative_to(R)):sha(p)for p in files};(O/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');data={'pid':proc.pid,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'exit_code':code,'stop':stop,'source_unchanged':before==after,'raw_errors':bool(re.search(r'SCRIPT ERROR:|Parse Error:|ERROR:',raw)),'scope':'Installed native material API and shared typed definition introspection only; no physical mesh/import/cache admission.'};(O/'receipt.json').write_text(json.dumps(data,indent=2)+'\n');print(raw);print(json.dumps(data,indent=2));raise SystemExit(0 if code==0 and not data['raw_errors']and before==after else 1)

from pathlib import Path
import hashlib,json,datetime,subprocess,os,signal,re,shutil,time
R=Path(__file__).resolve().parent;P=R/'physical-project';O=R/'semantic-import-03';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def src():return {str(p.relative_to(P)):sha(p)for p in sorted(P.rglob('*'))if p.is_file()and'.godot'not in p.relative_to(P).parts and p.name!='native-control.json'}
def cache():return {str(p.relative_to(P)):sha(p)for p in sorted((P/'.godot/imported').rglob('*'))if p.is_file()}
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
control=R/'native-control-01/native-control.json';control_sha=sha(control);before=src();cache_before=cache();(O/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');(O/'cache-before.json').write_text(json.dumps(cache_before,indent=2)+'\n');shutil.copy2(__file__,O/'launcher.py.txt');launcher_sha=sha(Path(__file__).resolve())
remap=P/'game/art/assets/tam_skateboard/tam_skateboard.glb.import';paths=re.findall(r'^path="res://([^"]+\.scn)"$',remap.read_text(),re.M);assert len(paths)==1
compiled=(P/paths[0]).resolve();assert compiled.is_relative_to((P/'.godot/imported').resolve())and compiled.name.startswith('tam_skateboard.glb-')
backup=O/'old-control-cache';backup.mkdir();removed=[]
for q in [compiled,compiled.with_suffix('.md5')]:
 if q.is_file():shutil.copy2(q,backup/q.name);removed.append({'path':str(q.relative_to(P)),'sha256':sha(q),'bytes':q.stat().st_size});q.unlink()
env=dict(os.environ)
for kind in ['DATA','CONFIG','CACHE']:
 q=O/('xdg-'+kind.lower());q.mkdir();env['XDG_'+kind+'_HOME']=str(q)
cmd=['/usr/local/bin/godot','--headless','--audio-driver','Dummy','--path',str(P),'--editor','--import'];start=utc();stop=None;clock=time.monotonic()
with(O/'import.log').open('w')as f:
 proc=subprocess.Popen(cmd,cwd=P,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);print(json.dumps({'pid':proc.pid,'start':start,'bound_seconds':90,'removed_private_board_cache':removed}),flush=True)
 try:code=proc.wait(timeout=90)
 except subprocess.TimeoutExpired:
  stop='OS90sdeadline';os.killpg(proc.pid,signal.SIGTERM)
  try:code=proc.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=3)
after=src();ca=cache();raw=(O/'import.log').read_text();(O/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');(O/'cache-after.json').write_text(json.dumps(ca,indent=2)+'\n');changed=[k for k in before.keys()|after.keys()if before.get(k)!=after.get(k)];generated_uids=[k for k in changed if k.endswith('.uid')and k not in before];unexpected=[k for k in changed if k not in generated_uids];errors=bool(re.search(r'SCRIPT ERROR:|Parse Error:|ERROR:',raw));d={'command':cmd,'pid':proc.pid,'start':start,'end':utc(),'seconds':time.monotonic()-clock,'bound_seconds':90,'exit_code':code,'stop':stop,'raw_errors':errors,'source_before_count':len(before),'source_after_count':len(after),'source_unexpected_changes':unexpected,'controlled_new_uid_outputs':generated_uids,'cache_changed':[k for k in cache_before.keys()|ca.keys()if cache_before.get(k)!=ca.get(k)],'old_control_output_preserved':sha(control)==control_sha,'launcher_unchanged':sha(Path(__file__).resolve())==launcher_sha,'removed_private_cache':removed,'eligible':bool(code==0 and not stop and not errors and not unexpected and compiled.is_file()and sha(control)==control_sha and sha(Path(__file__).resolve())==launcher_sha),'scope':'PRIVATE cold board-only scene reimport/final semantic metadata. Original control scene+md5 retained; no actual project/cache/source edits, no semantic runtime/native contact/PCK/Mac claim.'};(O/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2));print(raw[-2200:]);raise SystemExit(0 if d['eligible']else 1)

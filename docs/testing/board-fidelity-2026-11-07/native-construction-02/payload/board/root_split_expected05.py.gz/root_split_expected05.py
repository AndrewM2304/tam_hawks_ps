from pathlib import Path
import datetime,hashlib,json
R=Path(__file__).resolve().parent;P=R/'physical-project';D=R/'root-repair-05';D.mkdir(exist_ok=False)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
plan={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'PRIVATE source/codec continuation; no actual game source or cache change.','rejection':'semantic-import04 fails: PackedInt32Array constructors are not a GDScript constant expression. Earlier definition-constant-rejected01 already recorded this; root missed it. The immutable EXPECTED hash remains const; the editor certificate must use the supported typed static Dictionary.','runtime_ownership':'Move the full authoring certificate into tools/art. Runtime game/art/board_contact_definition.gd contains only immutable expected hashes; actual ownership arrives only in the cooked scene metadata. Avoid unused duplicate certificate constants/bytecode in runtime.','native_authority':'Retain the same reauthenticated actual native signatures digest and all5996 face owners/32 source parts. Rebind policy SHA to the exact revised importer and recompute immutable certificate hash. Native reimport must prove all new pins.','gates':'Before native import, parser validation of expected/editor certificate/validator; <=90s private reimport; <=45s native ownership/paired phantom/tyre/live invalidation and measured metadata+expected allocation. Retain the131072B gate; no tolerance/resource budget relaxation.'}
(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
importer=P/'tools/art/import_board_wood.gd';source=importer.read_text();(D/'before-importer.gd.txt').write_text(source)
old='  var definition:Script=load("res://game/art/board_contact_definition.gd")as Script';new='  var definition:Script=load("res://tools/art/board_contact_certificate.gd")as Script\n  var expected_definition:Script=load("res://game/art/board_contact_definition.gd")as Script';assert source.count(old)==1;source=source.replace(old,new)
old='  if definition==null or checker_script==null:return _refuse("missing cooked semantic definition/validator")';new='  if definition==null or expected_definition==null or checker_script==null:return _refuse("missing cooked semantic definition/validator")';assert source.count(old)==1;source=source.replace(old,new)
old='  var expected:Dictionary=definition.EXPECTED';assert source.count(old)==1;source=source.replace(old,'  var expected:Dictionary=expected_definition.EXPECTED');importer.write_text(source)
cert=json.loads((R/'root-repair-04/compact-certificate.json').read_text());cert['policy_sha256']=sha(source.encode())
expected=json.loads((R/'root-repair-04/expected.json').read_text());expected['policy_sha256']=cert['policy_sha256'];expected['certificate_sha256']=sha(canonical(cert))
def literal(value,path=()):
    if isinstance(value,dict):return '{'+','.join(json.dumps(k)+':'+literal(v,path+(k,))for k,v in sorted(value.items()))+'}'
    if isinstance(value,list):
        if path==('native_face_owners',):return '['+','.join('PackedInt32Array('+json.dumps(row,separators=(',',':'))+')'for row in value)+']'
        return '['+','.join(literal(v,path+(str(i),))for i,v in enumerate(value))+']'
    return json.dumps(value,ensure_ascii=False,separators=(',',':'))
runtime=P/'game/art/board_contact_definition.gd';(D/'before-runtime-definition.gd.txt').write_bytes(runtime.read_bytes())
runtime.write_text('extends RefCounted\n## PRIVATE runtime pin only. Typed ownership is read from the actual cooked scene.\nconst EXPECTED:='+literal(expected)+'\n')
editor=P/'tools/art/board_contact_certificate.gd';editor.write_text('@tool\nextends RefCounted\n## PRIVATE editor-only typed ownership from reauthenticated actual native geometry.\nstatic var CERTIFICATE:Dictionary='+literal(cert)+'\n')
probe=P/'semantic_runtime_probe.gd';text=probe.read_text();(D/'before-runtime-probe.gd.txt').write_text(text)
text=text.replace('const Definition=preload("res://game/art/board_contact_definition.gd")','var Definition:Script')
text=text.replace('func run()->void:\n','func run()->void:\n var expected_memory_before:int=OS.get_static_memory_usage()\n Definition=load("res://game/art/board_contact_definition.gd")as Script\n var expected_memory_delta:int=OS.get_static_memory_usage()-expected_memory_before\n',1)
text=text.replace(' check(independent_copy is Dictionary and independent_copy==certificate,"independent native certificate decode is exact")',' check(independent_copy is Dictionary and independent_copy==certificate,"independent native certificate decode is exact")\n check(metadata_delta+expected_memory_delta<=131072,"measured standalone certificate and runtime expected module stay within128KiB")')
text=text.replace('"independent_deserialized_certificate_static_delta_bytes":metadata_delta,','"independent_deserialized_certificate_static_delta_bytes":metadata_delta,"runtime_expected_static_delta_bytes":expected_memory_delta,"combined_component_provenance_delta_bytes":metadata_delta+expected_memory_delta,')
probe.write_text(text)
# These schema1 export/API fixtures have completed. Preserve them outside the
# importable project, where their old full runtime-definition assumptions belong.
retired=D/'retired-source';retired.mkdir()
for name in ['export_native_certificate.gd','material_api_probe.gd']:
    for suffix in ['', '.uid']:
        p=P/(name+suffix)
        if p.is_file():(retired/(p.name+'.txt')).write_bytes(p.read_bytes());p.unlink()
for name,p in [('after-importer.gd.txt',importer),('runtime-expected.gd.txt',runtime),('editor-certificate.gd.txt',editor),('runtime-probe.gd.txt',probe)]:
    (D/name).write_bytes(p.read_bytes())
(D/'compact-certificate.json').write_text(json.dumps(cert,indent=2)+'\n');(D/'expected.json').write_text(json.dumps(expected,indent=2)+'\n')
(D/'receipt.json').write_text(json.dumps({'editor_certificate_bytes':editor.stat().st_size,'runtime_expected_bytes':runtime.stat().st_size,'policy_sha256':expected['policy_sha256'],'certificate_sha256':expected['certificate_sha256'],'owners_unchanged':cert['native_face_owners']==json.loads((R/'root-native-cert-export-04/native-certificate.json').read_text())['certificate']['native_face_owners'],'scope':'Source transform and split only; native/parser/memory acceptance pending.'},indent=2)+'\n')
print('private expected module',runtime.stat().st_size,'bytes; full typed certificate editor-only')

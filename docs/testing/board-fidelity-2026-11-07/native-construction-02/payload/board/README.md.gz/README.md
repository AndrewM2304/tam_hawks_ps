# Private semantic board construction stage

No production source, asset, test, documentation, licence or Git file was edited.
No Godot process has run for this packet yet. The root granted one20-second
helper parser after releasing its inventory window; that hold is still pending.
Cold import, native control/query and final semantic admission are not authorised
by that parser-only lease.

Read `PLAN.md`, `specification.json`, `source-candidate-03-manifest.json`,
`source-negative-report.json` (70/0 source-only author controls), and the exact
`semantic_admission.py` / `semantic_board_cache.gd` sources. The prototype binds
all5,696 historical Native08 indexed faces once into32 source-owned volumes.
It derives support points from actual native indexed triangles; no supplied
source point buffer becomes shape authority. A reviewed immutable definition
hash binds membership, source/editor/decoder identities and all live array,
packed draw/shadow/LOD signatures. Global tree/vertex/index/packed-byte budgets
precede canonicalisation and hashes. Native runtime material/frame/Skin and
resource invalidation remain to be executed.

Canonical certificate size is25,095bytes, not measured Godot residency.
Physical cooked face rows must be PackedInt32Array. The128KiB retained metadata
gate and target cost remain unmeasured; bounded temporary canonicalisation is
startup-only. valid() adds four scalar surface-override pointer checks alongside
its frame/resource checks; no per-frame parsing, hashing, allocation, geometry
creation or physics query is proposed.

The legacy UV04 production constructor remains untouched. Its get_faces cache
quantizes points relative to indexed native arrays. The corrected diagnostic
`baseline-report.json` pairs32 components one-to-one using exact point count and
complete bounds:0 pointsets are bit exact and the largest indexed→legacy nearest
vertex difference is75.129µm. This is a diagnostic pairing, not an admitted cache
migration. The first nearest-centre report swapped concentric bearings/tyres and
is preserved as `baseline-report-01-rejected-nearest-centre.json`; its21mm deltas
are rejected. See `baseline-pairing-correction.json`.

The physical c7737… source contains5,996faces,32 semantic memberships and zero
ambiguous exact winding keys. It has no real native candidate certificate yet.
`physical-project` is a coherent cold private source with c7737… wood importer
and matching decoder; its control policy explicitly omits semantic installation.
`import_board_wood_semantic_final.gd` requires a generated typed definition and
fails closed on missing/invalid actual native metadata.

`native_control_probe.gd` and `emit_cooked_definition.py` are prepared, unparsed
and unrun. The former captures real imported buffers and queries the retained
legacy phantom witness; the latter refuses without a clean root-leased receipt
binding the actual native output. The emitted definition lives under game/art,
uses typed packed face rows, and requires final cold editor/native/empty-project
PCK validation. Never fabricate a native record from the source geometry to
unblock this sequence.

A separate source-only `loose-board-proposal` identifies the current bail collider
Box(.24,.12,.82) not enclosing the released UV04 model at the same identity frame:
its bottom is60mm above the actual tyre bottom. It proposes reusing the existing
whole-board convex shape in the same one collider. This is not a thin-board fix;
its actual native floor/inverted/tilted/inertia/rebound/pole/edge/recovery and
moving evidence remain required. The convex approximation is not an exact union
of32 concave physical pieces.

Next root-owned sequence: release parser hold; run the private≤20s parser with
prebound source/launcher; preserve and repair any parse failure. Independently
review code/70controls; grant a separate bounded cold import/native control only
if supported. Capture real source-bound native arrays, compile typed ownership,
then final cold import+metadata/runtime/native phantom negatives. Inventory and
migrate all deck/hanger/wheel/rest/manual/Casper/Pogo/grind/release/cache and
package expectations as one separately reviewed physical-board batch. Do not
promote a partial thin-deck asset or relabel historical evidence as current.

extends SceneTree
const Helper=preload("res://game/tricks/semantic_board_cache.gd")
var passed:=0
var failed:=0
func check(ok:bool,label:String)->void:
 if ok:passed+=1;print("PASS: ",label)
 else:failed+=1;push_error("FAIL: "+label)
func _initialize()->void:
 var helper:=Helper.new();var material:=StandardMaterial3D.new()
 check(helper._undeformed_material(material),"native standard material is eligible")
 material.grow=true
 check(not helper._undeformed_material(material),"enabled Grow refuses even at zero amount")
 material.grow_amount=.05
 check(not helper._undeformed_material(material),"positive Grow refuses")
 material.grow=false
 check(helper._undeformed_material(material),"disabled Grow amount supplies no deformation")
 material.next_pass=StandardMaterial3D.new()
 check(not helper._undeformed_material(material),"extra material pass refuses")
 material.next_pass=null;material.billboard_mode=BaseMaterial3D.BILLBOARD_ENABLED
 check(not helper._undeformed_material(material),"full billboard refuses")
 material.billboard_mode=BaseMaterial3D.BILLBOARD_FIXED_Y
 check(not helper._undeformed_material(material),"fixed Y billboard refuses")
 material.billboard_mode=BaseMaterial3D.BILLBOARD_DISABLED;material.fixed_size=true
 check(not helper._undeformed_material(material),"fixed size material refuses")
 material.fixed_size=false
 check(helper._undeformed_material(material),"restored native standard material is eligible")
 check(helper._sha(PackedByteArray())=="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855","native empty SHA256 matches the published digest without an invalid update")
 check(helper._sha("abc".to_utf8_buffer())=="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad","native nonempty SHA256 remains exact")
 var f:=FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE);f.store_string(JSON.stringify({"passed":passed,"failed":failed},"\t")+"\n");f.close()
 print("BOARD_MATERIAL_GUARD: ",passed," passed, ",failed," failed");quit(1 if failed else 0)

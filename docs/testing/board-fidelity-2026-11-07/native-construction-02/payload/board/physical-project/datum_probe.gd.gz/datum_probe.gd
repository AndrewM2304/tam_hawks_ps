extends SceneTree
func _initialize()->void:
 var records:Array=[]
 for mode:String in ["baseline","candidate"]:
  var scene:PackedScene=load("res://baseline_board.scn"if mode=="baseline"else"res://game/art/assets/tam_skateboard/tam_skateboard.glb")as PackedScene
  var model:Node3D=scene.instantiate();var nodes:Array=model.find_children("*","MeshInstance3D",true,false);var mesh:ArrayMesh=nodes[0].mesh
  var wheels:=PackedVector3Array();var grip:=PackedVector3Array();var midwood:=PackedVector3Array()
  for i:int in mesh.get_surface_count():
   var a:Array=mesh.surface_get_arrays(i);var vertices:PackedVector3Array=a[Mesh.ARRAY_VERTEX];var indices:PackedInt32Array=a[Mesh.ARRAY_INDEX]
   for index:int in indices:
    var v:Vector3=vertices[index]
    if i==3 and absf(v.x)>.09:wheels.append(v)
    elif i==1 and absf(v.z)<.05:grip.append(v)
    elif i==0 and absf(v.z)<.05:midwood.append(v)
  var bottom:=INF;var wheel_top:float=-INF;var grip_y:=INF;var lowwood:=INF;var highwood:float=-INF
  for v:Vector3 in wheels:bottom=minf(bottom,v.y);wheel_top=maxf(wheel_top,v.y)
  for v:Vector3 in grip:grip_y=minf(grip_y,v.y)
  for v:Vector3 in midwood:lowwood=minf(lowwood,v.y);highwood=maxf(highwood,v.y)
  records.append({"mode":mode,"wheel_ground_y_m":bottom,"wheel_top_y_m":wheel_top,"wheel_vertical_diameter_m":wheel_top-bottom,"grip_centre_y_m":grip_y,"grip_height_above_native_ground_m":grip_y-bottom,"sampled_midwood_low_m":lowwood,"sampled_midwood_high_m":highwood,"sampled_midwood_thickness_m":highwood-lowwood,"import_receipt":model.get_meta("tam_board_wood_import",{})})
  model.free()
 var f:=FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE);f.store_string(JSON.stringify({"records":records,"scope":"Actual indexed native position extrema at identity frame; Urethane wheels use the existing absX>.09 native inspector rule; central grip/wood samples are diagnostics, not whole-plane mating or final contact proof."},"\t")+"\n");f.close();print("NATIVE_BOARD_DATUMS ",JSON.stringify(records));quit()

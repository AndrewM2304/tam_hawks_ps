from pathlib import Path
import datetime,hashlib,json
R=Path(__file__).resolve().parent;P=R/'physical-project';D=R/'root-repair-04';D.mkdir(exist_ok=False)
receipt=json.loads((R/'root-native-cert-export-04/receipt.json').read_text());assert receipt['eligible']
record=json.loads((R/'root-native-cert-export-04/native-certificate.json').read_text())
assert record['actual_faces']==5996 and record['actual_parts']==32 and record['schema1_expected_certificate_matches']
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()
cert=record['certificate'];assert sha(canonical(cert))==record['expected']['certificate_sha256']
assert sha(canonical(cert['native_surfaces']))==record['actual_native_surface_digest']
compact=dict(cert);del compact['native_surfaces'];compact['schema']=2;compact['native_surfaces_sha256']=record['actual_native_surface_digest']
expected=dict(record['expected']);expected['certificate_sha256']=sha(canonical(compact))
plan={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'PRIVATE Schema2 cooked ownership codec and live material-state invalidation only; no production source/cache edit or physical-board adoption.','evidence':'Schema1 current native23/1: exact5996/32 authentication, paired phantom clears and tyre contact positives; realGrow setter fails invalidation. Independent full-certificate deserialization144704B exceeds131072B gate; do not raise that gate.','representation':'Replace detailed repeated per-surface signature Dictionaries with their SHA256, computed from the reauthenticated actual native export. Startup still reconstructs and hashes every indexed/packed/shadow/LOD signature. Complete packed face ownership remains. Immutable expected certificate hash binds the new digest and every owner. Schema1 is refused by this explicit prototype codec.','live_validation_budget':'Four additional _undeformed_material calls per valid(), at most16 current material-property reads (next_pass,grow,billboard_mode,fixed_size). No per-frame hash, allocation, scene scan or native query. Setter changed signals alone are insufficient.','retained_budget_bytes':131072,'added_render_resources':0,'native_query_delta':0,'native_input_receipt_sha256':sha((R/'root-native-cert-export-04/receipt.json').read_bytes()),'native_input_sha256':sha((R/'root-native-cert-export-04/native-certificate.json').read_bytes())}
(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
definition=P/'game/art/board_contact_definition.gd';(D/'before-definition.gd.txt').write_bytes(definition.read_bytes())
def literal(value,path=()):
    if isinstance(value,dict):return '{'+','.join(json.dumps(k)+':'+literal(v,path+(k,))for k,v in sorted(value.items()))+'}'
    if isinstance(value,list):
        if path==('native_face_owners',):return '['+','.join('PackedInt32Array('+json.dumps(row,separators=(',',':'))+')'for row in value)+']'
        return '['+','.join(literal(v,path+(str(i),))for i,v in enumerate(value))+']'
    return json.dumps(value,ensure_ascii=False,separators=(',',':'))
definition.write_text('extends RefCounted\n## PRIVATE generated from reauthenticated native schema1 output; exact face owners retained.\nconst CERTIFICATE:='+literal(compact)+'\nconst EXPECTED:='+literal(expected)+'\n')
paths=[R/'semantic_board_cache.gd',P/'game/tricks/semantic_board_cache.gd'];source=paths[0].read_text();assert source==paths[1].read_text();(D/'before-helper.gd.txt').write_text(source)
old=' if typeof(certificate.get("schema"))!=TYPE_INT or certificate.schema!=1:return _refuse("certificate schema")';new=old.replace('certificate.schema!=1','certificate.schema!=2');assert source.count(old)==1;source=source.replace(old,new)
old=' if actual.is_empty()or actual!=certificate.get("native_surfaces"):return _refuse("actual indexed/packed/shadow/LOD signature")'
new=''' if actual.is_empty()or not _sha_string(certificate.get("native_surfaces_sha256")):return _refuse("actual indexed/packed/shadow/LOD signature")
 var actual_bytes:PackedByteArray=JSON.stringify(_canonical_view(actual),"",true,true).to_utf8_buffer()
 if _sha(actual_bytes)!=certificate.native_surfaces_sha256:return _refuse("actual indexed/packed/shadow/LOD signature")''';assert source.count(old)==1;source=source.replace(old,new)
old='  if _mesh_instance.get_surface_override_material(surface)!=null:\n   _invalidate();rejection="stale surface override";return false'
new='''  if _mesh_instance.get_surface_override_material(surface)!=null or not _undeformed_material(_materials[surface]):
   _invalidate();rejection="stale surface override/deformation";return false''';assert source.count(old)==1;source=source.replace(old,new)
for p in paths:p.write_text(source)
(D/'after-helper.gd.txt').write_text(source);(D/'after-definition.gd.txt').write_bytes(definition.read_bytes());(D/'compact-certificate.json').write_text(json.dumps(compact,indent=2)+'\n');(D/'expected.json').write_text(json.dumps(expected,indent=2)+'\n')
(D/'receipt.json').write_text(json.dumps({'schema1_canonical_bytes':len(canonical(cert)),'schema2_canonical_bytes':len(canonical(compact)),'native_signature_digest':record['actual_native_surface_digest'],'source_face_owners_unchanged':compact['native_face_owners']==cert['native_face_owners'],'source_part_names_unchanged':compact['part_names']==cert['part_names'],'new_expected_certificate_sha256':expected['certificate_sha256'],'helper_sha256':sha(source.encode()),'definition_sha256':sha(definition.read_bytes()),'scope':'Source transformation with authenticated native inputs, not a native codec/runtime/memory pass.'},indent=2)+'\n')
print('private schema2 prepared; canonical bytes',len(canonical(cert)),'->',len(canonical(compact)))

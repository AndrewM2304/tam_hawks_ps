from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
D=Path(__file__).resolve().parent;P=D/'project';O=D/'import-01';O.mkdir(exist_ok=False)
def inv():return {str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(P.rglob('*'))if p.is_file()and'.godot'not in p.parts and'.local'not in p.relative_to(P).parts}
before=inv();(O/'before.json').write_text(json.dumps(before,indent=2)+'\n');start=time.monotonic();receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'deadline_seconds':120,'scope':'PRIVATE current-source full project/candidate board cold import only. New UID sidecars can be qualified separately; source edits, errors and timeout fail. No Main/contact adoption.','command':['./tools/run.sh','--headless','--audio-driver','Dummy','--editor','--import']}
with(O/'command.log').open('w')as log:
 p=subprocess.Popen(receipt['command'],cwd=P,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:receipt['exit_code']=p.wait(timeout=120)
 except subprocess.TimeoutExpired:
  receipt['timeout']=True;os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
after=inv();(O/'after.json').write_text(json.dumps(after,indent=2)+'\n');changed=sorted(k for k in before.keys()|after.keys()if before.get(k)!=after.get(k));new_uids=all(k not in before and k.endswith('.gd.uid')for k in changed)
receipt.update(wall_seconds=time.monotonic()-start,changed_inputs=changed,only_new_uid_sidecars=new_uids,errors=[x for x in(O/'command.log').read_text(errors='replace').splitlines()if any(t in x for t in['ERROR:','SCRIPT ERROR:','FAIL:','Parse Error:'])]);receipt['raw_eligible']=receipt.get('exit_code')==0 and not changed and not receipt['errors'];receipt['qualified_import']=receipt.get('exit_code')==0 and new_uids and not receipt['errors'];(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');(O/'observer.py.txt').write_bytes(Path(__file__).read_bytes());print(json.dumps(receipt),flush=True)
raise SystemExit(0 if receipt['qualified_import']else 1)

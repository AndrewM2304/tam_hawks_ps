extends SceneTree
const Skater=preload("res://game/player/skater.gd")
const Inputs=preload("res://game/core/input_setup.gd")
var records:Array=[]
func _initialize()->void:run.call_deferred()
func frames(n:int)->void:
	for i in n:await physics_frame;await process_frame
func quantile(a:Array,q:float)->float:
	var sorted:Array=a.duplicate();sorted.sort();return float(sorted[mini(sorted.size()-1,int(q*sorted.size()))])
func run()->void:
	Inputs.register_actions()
	var stage:=Node3D.new();root.add_child(stage)
	PhysicsServer3D.space_set_param(stage.get_world_3d().space,PhysicsServer3D.SPACE_PARAM_CONTACT_MAX_ALLOWED_PENETRATION,.001)
	var floor:=StaticBody3D.new();floor.collision_layer=1;floor.collision_mask=0;stage.add_child(floor)
	var col:=CollisionShape3D.new();var box:=BoxShape3D.new();box.size=Vector3(30,.3,30);col.shape=box;col.position.y=-.15;floor.add_child(col)
	var rider:=Skater.new();rider.spawn_position=Vector3(20,20,20);rider.set_process(false);rider.set_physics_process(false);stage.add_child(rider);rider.set_process(false);rider.set_physics_process(false)
	await frames(3)
	var original:Shape3D=rider._loose_board.get_child(0).shape
	for mode:String in ["box","components","box","components","box","components"]:
		rider._mount_board();var body:RigidBody3D=rider._loose_board
		for child:Node in body.get_children():
			if child is CollisionShape3D:child.free()
		var mem_before:int=OS.get_static_memory_usage();var start:int=Time.get_ticks_usec();var count:=0
		if mode=="components":
			for part:Dictionary in rider._grind_clearance._parts:
				var shape:=CollisionShape3D.new();shape.shape=part.shape;body.add_child(shape);count+=1
		else:
			var shape:=CollisionShape3D.new();shape.shape=original;body.add_child(shape);count=1
		var setup_us:int=Time.get_ticks_usec()-start;var retained:int=OS.get_static_memory_usage()-mem_before
		rider._drop_board();body.freeze=true
		await frames(3)
		var physics:Array=[];var intervals:Array=[];var cpu_start:int=Time.get_ticks_usec()
		for repeat in 12:
			body.freeze=true;body.global_transform=Transform3D(Basis.from_euler(Vector3(.35,0,.2)),Vector3(0,1.5,0));body.linear_velocity=Vector3(1,0,0);body.angular_velocity=Vector3(4,2,3);body.reset_physics_interpolation();await frames(1);body.freeze=false;body.sleeping=false
			for tick in 180:
				var begin:int=Time.get_ticks_usec();await frames(1);intervals.append(Time.get_ticks_usec()-begin)
				physics.append(Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS)*1000000.0)
		records.append({"mode":mode,"shape_nodes":count,"setup_us":setup_us,"retained_component_bytes":retained,"workload_wall_us":Time.get_ticks_usec()-cpu_start,"samples":physics.size(),"native_physics_us":{"p50":quantile(physics,.5),"p95":quantile(physics,.95),"p99":quantile(physics,.99)},"harness_interval_us":{"p50":quantile(intervals,.5),"p95":quantile(intervals,.95),"p99":quantile(intervals,.99)}})
		body.freeze=true;rider._mount_board()
	stage.free();await process_frame
	var f:=FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE);f.store_string(JSON.stringify({"scope":"Private uncontended headless native physics cost comparison: same actual board/body,12 initial-only falls per epoch,3 alternating pairs. Single-body fixed60Hz diagnostic, no rendering/M5/wholegame acceptance. Extra node memory includes native registration, reuses existing shape resources.","records":records},"\t")+"\n");f.close();print("LOOSE_COST_COMPLETE");quit()
